$(document).ready(function() {
  // Function to display the initial message
  function displayInitialMessage() {
    $('#content-container').html('<p>Click on a menu item to view the edit page.</p>');
  }

  // Load the initial message by default
  displayInitialMessage();

  // Function to load content when a menu item is clicked
  function loadContent(pageUrl) {
    $('#content-container').html('<p>Loading...</p>'); // Display a loading message
    $('#content-container').load(pageUrl); // Load the content from the clicked URL
  }

  // Load the profile page by default
  loadContent('profile.ejs');

  $('.menu-item').click(function(e) {
    e.preventDefault();
    var pageUrl = $(this).attr('href');
    loadContent(pageUrl); // Call the function to load content
  });
});