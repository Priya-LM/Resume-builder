// Fetch form data from the server
fetch('/data')
  .then(response => response.json())
  .then(formData => {
    // Render form data
    const formDataContainer = document.getElementById('formDataContainer');
    
    formData.forEach(data => {
      const dataDiv = document.createElement('div');
      dataDiv.innerHTML = `
        <h3>Name: ${data.name}</h3>
        <p>Email: ${data.email}</p>
        <p>Date of Birth: ${data.dob}</p>
        <p>Phone Number: ${data.phoneno}</p>
        <hr>
      `;
      formDataContainer.appendChild(dataDiv);
    });
  })
  .catch(error => {
    console.error('Error retrieving form data:', error);
  });



  const courses = {
    UG: ["Artificial Intelligence and Data Science", "Artificial Intelligence and Machine Learning", "Biotechnology Engineering", "Civil Engineering","Computer and Communication Engineering","Computer Science Engineering","Electronics and Communication Engineering","Electrical and Electronics Engineering","Information Science Engineering","Mechanical Engineering","Robotics and Artificial Intelligence"],
    PG: ["Construction Technology", "Computer Science Engineering", "Cyber Security","Electric Vehicle Technology","Structural Engineering","Machine Design","VLSI and Embedded System","MCA"]
  };
  
  function changeCourses() {
    const program = document.getElementById("program").value;
    const courseDropdown = document.getElementById("course");
    courseDropdown.innerHTML = ""; // clear existing options
    
    if (program !== "") {
      const programCourses = courses[program];
      const placeholderOption = document.createElement("option");
      placeholderOption.value = "";
      placeholderOption.disabled = true;
      placeholderOption.selected = true;
      placeholderOption.textContent = "Select a course";
      courseDropdown.appendChild(placeholderOption);

      for (let i = 0; i < programCourses.length; i++) {
        const option = document.createElement("option");
        option.text = programCourses[i];
        option.value = programCourses[i];
        courseDropdown.add(option);
      }
    }
  }


//Password Visibility
function toggleVisibility() {
  var x = document.getElementById("mypass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function vistog() {
  var x = document.getElementById("mypass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function passtog() {
  var x = document.getElementById("lpass");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}

function verifyPassword() {
  var nm = document.getElementById("name").value;
  var us = document.getElementById("usn").value;
  var bd = document.getElementById("dob").value;
  var em = document.getElementById("email").value;
  var phn = document.getElementById("phoneno").value;
  var pw = document.getElementById("password").value;
  var mps = document.getElementById("mypass").value;
  
  document.getElementById("error").innerHTML = "";
  
  if (pw.length < 8) {
    document.getElementById("error").innerHTML = "Password length must be at least 8 characters";
    
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    return false;
  }

  if (pw !== mps) {
    document.getElementById("error").innerHTML = "Password and Confirm password doesn't match!";
    
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });

    return false;
  }

  return true;
}
